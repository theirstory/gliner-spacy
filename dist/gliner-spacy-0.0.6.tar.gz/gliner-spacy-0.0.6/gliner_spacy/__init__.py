from gliner_spacy import *
from .version import __version__
